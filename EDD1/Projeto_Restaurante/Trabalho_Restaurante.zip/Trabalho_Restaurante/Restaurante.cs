﻿using System;

namespace Trabalho_Restaurante
{
    internal class Restaurante
    {
        private int proxPedido;
        private Pedido[] pedidos;

        public int ProxPedido
        {
            get => proxPedido;
        }

        internal Pedido[] Pedidos
        {
            get => pedidos;
        }

        public Restaurante()
        {
            this.proxPedido = 1;
            this.pedidos = new Pedido[50];
        }

        public bool novoPedido(Pedido pedido)
        {
            int i = 0;

            while (i < 50 && this.pedidos[i] != null)
            {
                i++;
            }

            if (i >= 50)
            {
                return false;
            }

            pedido.Id = this.proxPedido;
            this.proxPedido++;

            this.pedidos[i] = pedido;

            return true;
        }

        public Pedido buscarPedido(Pedido pedido)
        {
            int i = 0;

            while (i < 50)
            {
                if (this.pedidos[i] != null &&
                    this.pedidos[i].Equals(pedido))
                {
                    return this.pedidos[i];
                }

                i++;
            }

            return null;
        }

        public bool cancelarPedido(Pedido pedido)
        {
            int i = 0;

            while (i < 50)
            {
                if (this.pedidos[i] != null &&
                    this.pedidos[i].Equals(pedido))
                {
                    break;
                }

                i++;
            }

            if (i >= 50)
            {
                return false;
            }

            for (int j = i; j < 49; j++)
            {
                this.pedidos[j] = this.pedidos[j + 1];
            }

            this.pedidos[49] = null;

            return true;
        }
    }
}