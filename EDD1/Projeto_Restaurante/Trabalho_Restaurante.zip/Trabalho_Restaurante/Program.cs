﻿using System;

namespace Trabalho_Restaurante
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Restaurante restaurante = new Restaurante();
            int opcao;

            do
            {
                Console.Clear();

                Console.WriteLine("===== RESTAURANTE =====");
                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Criar novo pedido");
                Console.WriteLine("2. Adicionar item ao pedido");
                Console.WriteLine("3. Remover item do pedido");
                Console.WriteLine("4. Consultar pedido");
                Console.WriteLine("5. Cancelar pedido");
                Console.WriteLine("6. Listar todos os pedidos");
                Console.WriteLine();

                Console.Write("Opção: ");
                opcao = int.Parse(Console.ReadLine());

                Console.WriteLine();

                switch (opcao)
                {
                    case 0:
                        Console.WriteLine("Programa encerrado.");
                        break;

                    case 1:
                        criarPedido(restaurante);
                        break;

                    case 2:
                        adicionarItem(restaurante);
                        break;

                    case 3:
                        removerItem(restaurante);
                        break;

                    case 4:
                        consultarPedido(restaurante);
                        break;

                    case 5:
                        cancelarPedido(restaurante);
                        break;

                    case 6:
                        listarPedidos(restaurante);
                        break;

                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }

                if (opcao != 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("Pressione ENTER para continuar...");
                    Console.ReadLine();
                }

            } while (opcao != 0);
        }

        static void criarPedido(Restaurante restaurante)
        {
            Console.Write("Nome do cliente: ");
            string cliente = Console.ReadLine();

            Pedido pedido = new Pedido(0, cliente);

            if (restaurante.novoPedido(pedido))
            {
                Console.WriteLine("Pedido criado com sucesso.");
                Console.WriteLine("Número do pedido: " + pedido.Id);
            }
            else
            {
                Console.WriteLine("Limite máximo de pedidos atingido.");
            }
        }

        static void adicionarItem(Restaurante restaurante)
        {
            Console.Write("Informe o número do pedido: ");
            int idPedido = int.Parse(Console.ReadLine());

            Pedido pedido =
                restaurante.buscarPedido(new Pedido(idPedido, ""));

            if (pedido == null)
            {
                Console.WriteLine("Pedido não encontrado.");
                return;
            }

            Console.Write("ID do item: ");
            int idItem = int.Parse(Console.ReadLine());

            Console.Write("Descrição do item: ");
            string descricao = Console.ReadLine();

            Console.Write("Preço do item: ");
            double preco = double.Parse(Console.ReadLine());

            Item item = new Item(idItem, descricao, preco);

            if (pedido.adicionarItem(item))
            {
                Console.WriteLine("Item adicionado com sucesso.");
            }
            else
            {
                Console.WriteLine("O pedido já possui 10 itens.");
            }
        }

        static void removerItem(Restaurante restaurante)
        {
            Console.Write("Informe o número do pedido: ");
            int idPedido = int.Parse(Console.ReadLine());

            Pedido pedido =
                restaurante.buscarPedido(new Pedido(idPedido, ""));

            if (pedido == null)
            {
                Console.WriteLine("Pedido não encontrado.");
                return;
            }

            Console.Write("Informe o ID do item: ");
            int idItem = int.Parse(Console.ReadLine());

            Item item = new Item(idItem, "", 0);

            if (pedido.removerItem(item))
            {
                Console.WriteLine("Item removido com sucesso.");
            }
            else
            {
                Console.WriteLine("Item não encontrado.");
            }
        }

        static void consultarPedido(Restaurante restaurante)
        {
            Console.Write("Informe o número do pedido: ");
            int idPedido = int.Parse(Console.ReadLine());

            Pedido pedido =
                restaurante.buscarPedido(new Pedido(idPedido, ""));

            if (pedido == null)
            {
                Console.WriteLine("Pedido não encontrado.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("===== PEDIDO =====");
            Console.WriteLine(pedido.dadosDoPedido());
        }

        static void cancelarPedido(Restaurante restaurante)
        {
            Console.Write("Informe o número do pedido: ");
            int idPedido = int.Parse(Console.ReadLine());

            Pedido pedido = new Pedido(idPedido, "");

            if (restaurante.cancelarPedido(pedido))
            {
                Console.WriteLine("Pedido cancelado com sucesso.");
            }
            else
            {
                Console.WriteLine("Pedido não encontrado.");
            }
        }

        static void listarPedidos(Restaurante restaurante)
        {
            double totalGeral = 0;
            bool possuiPedido = false;

            Console.WriteLine("===== PEDIDOS DO DIA =====");

            for (int i = 0; i < 50; i++)
            {
                Pedido pedido = restaurante.Pedidos[i];

                if (pedido != null)
                {
                    possuiPedido = true;

                    Console.WriteLine();
                    Console.WriteLine("Pedido: " + pedido.Id);
                    Console.WriteLine("Cliente: " + pedido.Cliente);
                    Console.WriteLine("Valor total: " +
                                      pedido.calcularTotal().ToString("C2"));
                    Console.WriteLine("-----------------------------");

                    totalGeral += pedido.calcularTotal();
                }
            }

            if (!possuiPedido)
            {
                Console.WriteLine("Nenhum pedido cadastrado.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("Soma geral do dia: " +
                              totalGeral.ToString("C2"));
        }
    }
}