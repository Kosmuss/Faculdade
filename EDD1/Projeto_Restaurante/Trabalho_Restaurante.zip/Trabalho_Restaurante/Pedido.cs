﻿using System;

namespace Trabalho_Restaurante
{
    internal class Pedido
    {
        private int id;
        private string cliente;
        private Item[] itens;

        public int Id
        {
            get => id;
            set => id = value;
        }

        public string Cliente
        {
            get => cliente;
            set => cliente = value;
        }

        internal Item[] Itens
        {
            get => itens;
        }

        public Pedido(int id, string cliente)
        {
            this.Id = id;
            this.Cliente = cliente;
            this.itens = new Item[10];
        }

        public Pedido() : this(0, "")
        {
        }

        public bool adicionarItem(Item item)
        {
            int i = 0;

            while (i < 10 && this.itens[i] != null)
            {
                i++;
            }

            if (i < 10)
            {
                this.itens[i] = item;
                return true;
            }

            return false;
        }

        public bool removerItem(Item item)
        {
            int i = 0;

            while (i < 10 &&
                   (this.itens[i] == null || !this.itens[i].Equals(item)))
            {
                i++;
            }

            if (i >= 10)
            {
                return false;
            }

            for (int j = i; j < 9; j++)
            {
                this.itens[j] = this.itens[j + 1];
            }

            this.itens[9] = null;

            return true;
        }

        public string dadosDoPedido()
        {
            string dados = "";

            dados += "ID: " + this.Id + "\n";
            dados += "Cliente: " + this.Cliente + "\n";
            dados += "Itens:\n";

            bool possuiItem = false;

            for (int i = 0; i < 10; i++)
            {
                if (this.itens[i] != null)
                {
                    possuiItem = true;

                    dados += this.itens[i].Id + " - ";
                    dados += this.itens[i].Descricao + " - ";
                    dados += this.itens[i].Preco.ToString("C2") + "\n";
                }
            }

            if (!possuiItem)
            {
                dados += "Nenhum item cadastrado.\n";
            }

            dados += "Valor total: " +
                     this.calcularTotal().ToString("C2");

            return dados;
        }

        public double calcularTotal()
        {
            double total = 0;

            for (int i = 0; i < 10; i++)
            {
                if (this.itens[i] != null)
                {
                    total += this.itens[i].Preco;
                }
            }

            return total;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is Pedido))
            {
                return false;
            }

            return this.Id.Equals(((Pedido)obj).Id);
        }
    }
}