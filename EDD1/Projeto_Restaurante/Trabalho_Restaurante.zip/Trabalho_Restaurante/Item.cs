﻿using System;

namespace Trabalho_Restaurante
{
    internal class Item
    {
        private int id;
        private string descricao;
        private double preco;

        public int Id
        {
            get => id;
            set => id = value;
        }

        public string Descricao
        {
            get => descricao;
            set => descricao = value;
        }

        public double Preco
        {
            get => preco;
            set => preco = value;
        }

        public Item(int id, string descricao, double preco)
        {
            this.Id = id;
            this.Descricao = descricao;
            this.Preco = preco;
        }

        public Item() : this(0, "", 0)
        {
        }

        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is Item))
            {
                return false;
            }

            return this.Id.Equals(((Item)obj).Id);
        }
    }
}