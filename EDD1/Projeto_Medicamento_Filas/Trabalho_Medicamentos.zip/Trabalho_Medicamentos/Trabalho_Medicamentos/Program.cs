﻿using System;

namespace Trabalho_Medicamentos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Medicamentos medicamentos = new Medicamentos();
            int opcao;

            do
            {
                Console.Clear();

                Console.WriteLine("===== FARMÁCIA =====");
                Console.WriteLine("0. Finalizar processo");
                Console.WriteLine("1. Cadastrar medicamento");
                Console.WriteLine("2. Consultar medicamento (sintético)");
                Console.WriteLine("3. Consultar medicamento (analítico)");
                Console.WriteLine("4. Comprar medicamento");
                Console.WriteLine("5. Vender medicamento");
                Console.WriteLine("6. Listar medicamentos");
                Console.WriteLine();

                Console.Write("Opção: ");
                opcao = int.Parse(Console.ReadLine());

                Console.WriteLine();

                switch (opcao)
                {
                    case 0:
                        Console.WriteLine("Processo finalizado.");
                        break;

                    case 1:
                        cadastrarMedicamento(medicamentos);
                        break;

                    case 2:
                        consultarSintetico(medicamentos);
                        break;

                    case 3:
                        consultarAnalitico(medicamentos);
                        break;

                    case 4:
                        comprarMedicamento(medicamentos);
                        break;

                    case 5:
                        venderMedicamento(medicamentos);
                        break;

                    case 6:
                        listarMedicamentos(medicamentos);
                        break;

                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }

                if (opcao != 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("Pressione ENTER para continuar...");
                    Console.ReadLine();
                }

            } while (opcao != 0);
        }

        static void cadastrarMedicamento(Medicamentos medicamentos)
        {
            Console.Write("ID do medicamento: ");
            int id = int.Parse(Console.ReadLine());

            Medicamento existente =
                medicamentos.pesquisar(
                    new Medicamento(id, "", "")
                );

            if (existente.Id != 0)
            {
                Console.WriteLine(
                    "Já existe um medicamento com esse ID."
                );
                return;
            }

            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Laboratório: ");
            string laboratorio = Console.ReadLine();

            Medicamento medicamento =
                new Medicamento(id, nome, laboratorio);

            medicamentos.adicionar(medicamento);

            Console.WriteLine(
                "Medicamento cadastrado com sucesso."
            );
        }

        static Medicamento procurarMedicamento(
            Medicamentos medicamentos)
        {
            Console.Write("Informe o ID do medicamento: ");
            int id = int.Parse(Console.ReadLine());

            return medicamentos.pesquisar(
                new Medicamento(id, "", "")
            );
        }

        static void consultarSintetico(
            Medicamentos medicamentos)
        {
            Medicamento medicamento =
                procurarMedicamento(medicamentos);

            if (medicamento.Id == 0)
            {
                Console.WriteLine(
                    "Medicamento não encontrado."
                );
                return;
            }

            Console.WriteLine();
            Console.WriteLine("===== MEDICAMENTO =====");
            Console.WriteLine(medicamento.toString());
        }

        static void consultarAnalitico(
            Medicamentos medicamentos)
        {
            Medicamento medicamento =
                procurarMedicamento(medicamentos);

            if (medicamento.Id == 0)
            {
                Console.WriteLine(
                    "Medicamento não encontrado."
                );
                return;
            }

            Console.WriteLine();
            Console.WriteLine("===== MEDICAMENTO =====");

            Console.WriteLine(
                "ID: " + medicamento.Id
            );

            Console.WriteLine(
                "Nome: " + medicamento.Nome
            );

            Console.WriteLine(
                "Laboratório: " + medicamento.Laboratorio
            );

            Console.WriteLine(
                "Quantidade disponível: " +
                medicamento.qtdeDisponivel()
            );

            Console.WriteLine();
            Console.WriteLine("===== LOTES =====");

            if (medicamento.Lotes.Count == 0)
            {
                Console.WriteLine(
                    "Nenhum lote disponível."
                );

                return;
            }

            foreach (Lote lote in medicamento.Lotes)
            {
                Console.WriteLine(
                    lote.toString()
                );
            }
        }

        static void comprarMedicamento(
            Medicamentos medicamentos)
        {
            Medicamento medicamento =
                procurarMedicamento(medicamentos);

            if (medicamento.Id == 0)
            {
                Console.WriteLine(
                    "Medicamento não encontrado."
                );
                return;
            }

            Console.Write("ID do lote: ");
            int idLote = int.Parse(Console.ReadLine());

            Console.Write("Quantidade: ");
            int qtde = int.Parse(Console.ReadLine());

            Console.Write("Dia do vencimento: ");
            int dia = int.Parse(Console.ReadLine());

            Console.Write("Mês do vencimento: ");
            int mes = int.Parse(Console.ReadLine());

            Console.Write("Ano do vencimento: ");
            int ano = int.Parse(Console.ReadLine());

            DateTime vencimento =
                new DateTime(ano, mes, dia);

            Lote lote =
                new Lote(
                    idLote,
                    qtde,
                    vencimento
                );

            medicamento.comprar(lote);

            Console.WriteLine(
                "Lote cadastrado com sucesso."
            );
        }

        static void venderMedicamento(
            Medicamentos medicamentos)
        {
            Medicamento medicamento =
                procurarMedicamento(medicamentos);

            if (medicamento.Id == 0)
            {
                Console.WriteLine(
                    "Medicamento não encontrado."
                );
                return;
            }

            Console.WriteLine(
                "Quantidade disponível: " +
                medicamento.qtdeDisponivel()
            );

            Console.Write("Quantidade a vender: ");
            int qtde = int.Parse(Console.ReadLine());

            if (medicamento.vender(qtde))
            {
                Console.WriteLine(
                    "Venda realizada com sucesso."
                );

                Console.WriteLine(
                    "Quantidade restante: " +
                    medicamento.qtdeDisponivel()
                );
            }
            else
            {
                Console.WriteLine(
                    "Quantidade insuficiente para realizar a venda."
                );
            }
        }

        static void listarMedicamentos(
            Medicamentos medicamentos)
        {
            if (medicamentos.ListaMedicamentos.Count == 0)
            {
                Console.WriteLine(
                    "Nenhum medicamento cadastrado."
                );
                return;
            }

            Console.WriteLine(
                "===== MEDICAMENTOS ====="
            );

            foreach (Medicamento medicamento
                     in medicamentos.ListaMedicamentos)
            {
                Console.WriteLine(
                    medicamento.toString()
                );
            }
        }
    }
}