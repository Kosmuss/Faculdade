﻿using System;

namespace Trabalho_Medicamentos
{
    internal class Lote
    {
        private int id;
        private int qtde;
        private DateTime venc;

        public int Id
        {
            get => id;
            set => id = value;
        }

        public int Qtde
        {
            get => qtde;
            set => qtde = value;
        }

        public DateTime Venc
        {
            get => venc;
            set => venc = value;
        }

        public Lote()
        {
            this.Id = 0;
            this.Qtde = 0;
            this.Venc = DateTime.MinValue;
        }

        public Lote(int id, int qtde, DateTime venc)
        {
            this.Id = id;
            this.Qtde = qtde;
            this.Venc = venc;
        }

        public string toString()
        {
            return this.Id + " - " +
                   this.Qtde + " - " +
                   this.Venc.ToString("dd/MM/yyyy");
        }
    }
}