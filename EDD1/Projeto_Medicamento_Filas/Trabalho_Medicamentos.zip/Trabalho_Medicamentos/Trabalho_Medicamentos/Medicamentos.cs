﻿using System;
using System.Collections.Generic;

namespace Trabalho_Medicamentos
{
    internal class Medicamentos
    {
        private List<Medicamento> listaMedicamentos;

        public List<Medicamento> ListaMedicamentos
        {
            get => listaMedicamentos;
        }

        public Medicamentos()
        {
            this.listaMedicamentos = new List<Medicamento>();
        }

        public void adicionar(Medicamento medicamento)
        {
            this.listaMedicamentos.Add(medicamento);
        }

        public bool deletar(Medicamento medicamento)
        {
            Medicamento medicamentoAchado =
                this.pesquisar(medicamento);

            if (medicamentoAchado.Id == 0)
            {
                return false;
            }

            if (medicamentoAchado.qtdeDisponivel() != 0)
            {
                return false;
            }

            this.listaMedicamentos.Remove(medicamentoAchado);

            return true;
        }

        public Medicamento pesquisar(Medicamento medicamento)
        {
            foreach (Medicamento m in this.listaMedicamentos)
            {
                if (m.Equals(medicamento))
                {
                    return m;
                }
            }

            return new Medicamento();
        }
    }
}