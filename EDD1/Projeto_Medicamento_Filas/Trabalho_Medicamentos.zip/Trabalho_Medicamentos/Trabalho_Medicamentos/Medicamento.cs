﻿using System;
using System.Collections.Generic;

namespace Trabalho_Medicamentos
{
    internal class Medicamento
    {
        private int id;
        private string nome;
        private string laboratorio;
        private Queue<Lote> lotes;

        public int Id
        {
            get => id;
            set => id = value;
        }

        public string Nome
        {
            get => nome;
            set => nome = value;
        }

        public string Laboratorio
        {
            get => laboratorio;
            set => laboratorio = value;
        }

        public Queue<Lote> Lotes
        {
            get => lotes;
        }

        public Medicamento()
        {
            this.Id = 0;
            this.Nome = "";
            this.Laboratorio = "";
            this.lotes = new Queue<Lote>();
        }

        public Medicamento(int id, string nome, string laboratorio)
        {
            this.Id = id;
            this.Nome = nome;
            this.Laboratorio = laboratorio;
            this.lotes = new Queue<Lote>();
        }

        public int qtdeDisponivel()
        {
            int total = 0;

            foreach (Lote lote in this.lotes)
            {
                total += lote.Qtde;
            }

            return total;
        }

        public void comprar(Lote lote)
        {
            this.lotes.Enqueue(lote);
        }

        public bool vender(int qtde)
        {
            if (qtde <= 0 || this.qtdeDisponivel() < qtde)
            {
                return false;
            }

            int restante = qtde;

            while (restante > 0)
            {
                Lote lote = this.lotes.Peek();

                if (lote.Qtde <= restante)
                {
                    restante -= lote.Qtde;
                    lote.Qtde = 0;
                    this.lotes.Dequeue();
                }
                else
                {
                    lote.Qtde -= restante;
                    restante = 0;
                }
            }

            return true;
        }

        public string toString()
        {
            return this.Id + " - " +
                   this.Nome + " - " +
                   this.Laboratorio + " - " +
                   this.qtdeDisponivel();
        }

        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is Medicamento))
            {
                return false;
            }

            return this.Id.Equals(((Medicamento)obj).Id);
        }
    }
}