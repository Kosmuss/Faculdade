﻿using System;
using System.Collections.Generic;

namespace Trabalho_Agenda
{
    internal class Contatos
    {
        private List<Contato> agenda;

        public List<Contato> Agenda
        {
            get => agenda;
        }

        public Contatos()
        {
            this.agenda = new List<Contato>();
        }

        public bool adicionar(Contato c)
        {
            if (this.pesquisar(c) != null)
            {
                return false;
            }

            this.agenda.Add(c);

            return true;
        }

        public Contato pesquisar(Contato c)
        {
            foreach (Contato contato in this.agenda)
            {
                if (contato.Equals(c))
                {
                    return contato;
                }
            }

            return null;
        }

        public bool alterar(Contato c)
        {
            Contato contatoAchado = this.pesquisar(c);

            if (contatoAchado == null)
            {
                return false;
            }

            contatoAchado.Nome = c.Nome;
            contatoAchado.DtNasc = c.DtNasc;

            contatoAchado.Telefones.Clear();

            foreach (Telefone telefone in c.Telefones)
            {
                contatoAchado.adicionarTelefone(telefone);
            }

            return true;
        }

        public bool remover(Contato c)
        {
            Contato contatoAchado = this.pesquisar(c);

            if (contatoAchado == null)
            {
                return false;
            }

            this.agenda.Remove(contatoAchado);

            return true;
        }
    }
}