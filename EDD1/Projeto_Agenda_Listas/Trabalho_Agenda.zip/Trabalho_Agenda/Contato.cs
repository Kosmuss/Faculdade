﻿using System;
using System.Collections.Generic;

namespace Trabalho_Agenda
{
    internal class Contato
    {
        private string email;
        private string nome;
        private Data dtNasc;
        private List<Telefone> telefones;

        public string Email
        {
            get => email;
            set => email = value;
        }

        public string Nome
        {
            get => nome;
            set => nome = value;
        }

        public Data DtNasc
        {
            get => dtNasc;
            set => dtNasc = value;
        }

        public List<Telefone> Telefones
        {
            get => telefones;
        }

        public Contato(string email, string nome, Data dtNasc)
        {
            this.Email = email;
            this.Nome = nome;
            this.DtNasc = dtNasc;
            this.telefones = new List<Telefone>();
        }

        public Contato() : this("", "", new Data())
        {
        }

        public int getIdade()
        {
            DateTime hoje = DateTime.Today;

            int idade = hoje.Year - this.DtNasc.Ano;

            if (hoje.Month < this.DtNasc.Mes ||
                (hoje.Month == this.DtNasc.Mes &&
                 hoje.Day < this.DtNasc.Dia))
            {
                idade--;
            }

            return idade;
        }

        public void adicionarTelefone(Telefone t)
        {
            if (t.Principal)
            {
                foreach (Telefone telefone in this.telefones)
                {
                    telefone.Principal = false;
                }
            }

            this.telefones.Add(t);
        }

        public string getTelefonePrincipal()
        {
            foreach (Telefone telefone in this.telefones)
            {
                if (telefone.Principal)
                {
                    return telefone.Numero;
                }
            }

            return "Não informado";
        }

        public override string ToString()
        {
            string dados = "";

            dados += "Nome: " + this.Nome + "\n";
            dados += "E-mail: " + this.Email + "\n";
            dados += "Data de nascimento: " + this.DtNasc.ToString() + "\n";
            dados += "Idade: " + this.getIdade() + "\n";
            dados += "Telefone principal: " + this.getTelefonePrincipal();

            return dados;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is Contato))
            {
                return false;
            }

            return this.Email.Equals(((Contato)obj).Email);
        }
    }
}