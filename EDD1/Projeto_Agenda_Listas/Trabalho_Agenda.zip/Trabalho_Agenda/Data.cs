﻿using System;

namespace Trabalho_Agenda
{
    internal class Data
    {
        private int dia;
        private int mes;
        private int ano;

        public int Dia
        {
            get => dia;
            set => dia = value;
        }

        public int Mes
        {
            get => mes;
            set => mes = value;
        }

        public int Ano
        {
            get => ano;
            set => ano = value;
        }

        public Data(int dia, int mes, int ano)
        {
            setData(dia, mes, ano);
        }

        public Data() : this(1, 1, 2000)
        {
        }

        public void setData(int dia, int mes, int ano)
        {
            this.Dia = dia;
            this.Mes = mes;
            this.Ano = ano;
        }

        public override string ToString()
        {
            return this.Dia.ToString("00") + "/" +
                   this.Mes.ToString("00") + "/" +
                   this.Ano.ToString("0000");
        }
    }
}