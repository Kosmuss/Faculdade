﻿using System;

namespace Trabalho_Agenda
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Contatos contatos = new Contatos();
            int opcao;

            do
            {
                Console.Clear();

                Console.WriteLine("===== AGENDA =====");
                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Adicionar contato");
                Console.WriteLine("2. Pesquisar contato");
                Console.WriteLine("3. Alterar contato");
                Console.WriteLine("4. Remover contato");
                Console.WriteLine("5. Listar contatos");
                Console.WriteLine();

                Console.Write("Opção: ");
                opcao = int.Parse(Console.ReadLine());

                Console.WriteLine();

                switch (opcao)
                {
                    case 0:
                        Console.WriteLine("Programa encerrado.");
                        break;

                    case 1:
                        adicionarContato(contatos);
                        break;

                    case 2:
                        pesquisarContato(contatos);
                        break;

                    case 3:
                        alterarContato(contatos);
                        break;

                    case 4:
                        removerContato(contatos);
                        break;

                    case 5:
                        listarContatos(contatos);
                        break;

                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }

                if (opcao != 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("Pressione ENTER para continuar...");
                    Console.ReadLine();
                }

            } while (opcao != 0);
        }

        static void adicionarContato(Contatos contatos)
        {
            Console.Write("E-mail: ");
            string email = Console.ReadLine();

            if (contatos.pesquisar(new Contato(email, "", new Data())) != null)
            {
                Console.WriteLine("Já existe um contato com esse e-mail.");
                return;
            }

            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Dia do nascimento: ");
            int dia = int.Parse(Console.ReadLine());

            Console.Write("Mês do nascimento: ");
            int mes = int.Parse(Console.ReadLine());

            Console.Write("Ano do nascimento: ");
            int ano = int.Parse(Console.ReadLine());

            Contato contato =
                new Contato(email, nome, new Data(dia, mes, ano));

            adicionarTelefones(contato);

            if (contatos.adicionar(contato))
            {
                Console.WriteLine("Contato adicionado com sucesso.");
            }
            else
            {
                Console.WriteLine("Não foi possível adicionar o contato.");
            }
        }

        static void adicionarTelefones(Contato contato)
        {
            string continuar;

            do
            {
                Console.WriteLine();
                Console.Write("Tipo do telefone: ");
                string tipo = Console.ReadLine();

                Console.Write("Número: ");
                string numero = Console.ReadLine();

                Console.Write("É o telefone principal? (S/N): ");
                string resposta = Console.ReadLine();

                bool principal =
                    resposta.ToUpper() == "S";

                Telefone telefone =
                    new Telefone(tipo, numero, principal);

                contato.adicionarTelefone(telefone);

                Console.Write("Adicionar outro telefone? (S/N): ");
                continuar = Console.ReadLine();

            } while (continuar.ToUpper() == "S");
        }

        static void pesquisarContato(Contatos contatos)
        {
            Console.Write("Informe o e-mail: ");
            string email = Console.ReadLine();

            Contato contato =
                contatos.pesquisar(
                    new Contato(email, "", new Data())
                );

            if (contato == null)
            {
                Console.WriteLine("Contato não encontrado.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("===== CONTATO =====");
            Console.WriteLine(contato.ToString());
        }

        static void alterarContato(Contatos contatos)
        {
            Console.Write("Informe o e-mail do contato: ");
            string email = Console.ReadLine();

            Contato existente =
                contatos.pesquisar(
                    new Contato(email, "", new Data())
                );

            if (existente == null)
            {
                Console.WriteLine("Contato não encontrado.");
                return;
            }

            Console.Write("Novo nome: ");
            string nome = Console.ReadLine();

            Console.Write("Novo dia de nascimento: ");
            int dia = int.Parse(Console.ReadLine());

            Console.Write("Novo mês de nascimento: ");
            int mes = int.Parse(Console.ReadLine());

            Console.Write("Novo ano de nascimento: ");
            int ano = int.Parse(Console.ReadLine());

            Contato novoContato =
                new Contato(
                    email,
                    nome,
                    new Data(dia, mes, ano)
                );

            adicionarTelefones(novoContato);

            if (contatos.alterar(novoContato))
            {
                Console.WriteLine("Contato alterado com sucesso.");
            }
            else
            {
                Console.WriteLine("Não foi possível alterar o contato.");
            }
        }

        static void removerContato(Contatos contatos)
        {
            Console.Write("Informe o e-mail: ");
            string email = Console.ReadLine();

            Contato contato =
                new Contato(email, "", new Data());

            if (contatos.remover(contato))
            {
                Console.WriteLine("Contato removido com sucesso.");
            }
            else
            {
                Console.WriteLine("Contato não encontrado.");
            }
        }

        static void listarContatos(Contatos contatos)
        {
            if (contatos.Agenda.Count == 0)
            {
                Console.WriteLine("Agenda vazia.");
                return;
            }

            Console.WriteLine("===== CONTATOS =====");

            foreach (Contato contato in contatos.Agenda)
            {
                Console.WriteLine();
                Console.WriteLine(contato.ToString());
                Console.WriteLine("-----------------------------");
            }
        }
    }
}