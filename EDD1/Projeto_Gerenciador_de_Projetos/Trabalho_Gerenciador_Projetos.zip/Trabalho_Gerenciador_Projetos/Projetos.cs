﻿using System;
using System.Collections.Generic;

namespace Trabalho_Gerenciador_Projetos
{
    internal class Projetos
    {
        private List<Projeto> itens;

        public List<Projeto> Itens
        {
            get => itens;
        }

        public Projetos()
        {
            this.itens = new List<Projeto>();
        }

        public bool adicionar(Projeto p)
        {
            if (this.buscar(p) != null)
            {
                return false;
            }

            this.itens.Add(p);

            return true;
        }

        public bool remover(Projeto p)
        {
            Projeto projetoAchado = this.buscar(p);

            if (projetoAchado == null)
            {
                return false;
            }

            if (projetoAchado.Tarefas.Count > 0)
            {
                return false;
            }

            this.itens.Remove(projetoAchado);

            return true;
        }

        public Projeto buscar(Projeto p)
        {
            foreach (Projeto projeto in this.itens)
            {
                if (projeto.Id == p.Id)
                {
                    return projeto;
                }
            }

            return null;
        }

        public List<Projeto> listar()
        {
            return this.itens;
        }
    }
}