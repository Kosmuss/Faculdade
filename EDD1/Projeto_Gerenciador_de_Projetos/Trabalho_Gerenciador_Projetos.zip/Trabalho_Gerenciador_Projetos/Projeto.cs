﻿using System;
using System.Collections.Generic;

namespace Trabalho_Gerenciador_Projetos
{
    internal class Projeto
    {
        private int id;
        private string nome;
        private List<Tarefa> tarefas;

        public int Id
        {
            get => id;
            set => id = value;
        }

        public string Nome
        {
            get => nome;
            set => nome = value;
        }

        public List<Tarefa> Tarefas
        {
            get => tarefas;
        }

        public Projeto(int id, string nome)
        {
            this.Id = id;
            this.Nome = nome;
            this.tarefas = new List<Tarefa>();
        }

        public Projeto() : this(0, "")
        {
        }

        public void adicionarTarefa(Tarefa t)
        {
            this.tarefas.Add(t);
        }

        public bool removerTarefa(Tarefa t)
        {
            Tarefa tarefaAchada = this.buscarTarefa(t);

            if (tarefaAchada == null)
            {
                return false;
            }

            this.tarefas.Remove(tarefaAchada);

            return true;
        }

        public Tarefa buscarTarefa(Tarefa t)
        {
            foreach (Tarefa tarefa in this.tarefas)
            {
                if (tarefa.Id == t.Id)
                {
                    return tarefa;
                }
            }

            return null;
        }

        public List<Tarefa> tarefasPorStatus(string s)
        {
            List<Tarefa> resultado = new List<Tarefa>();

            foreach (Tarefa tarefa in this.tarefas)
            {
                if (tarefa.Status == s)
                {
                    resultado.Add(tarefa);
                }
            }

            return resultado;
        }

        public List<Tarefa> tarefasPorPrioridade(int p)
        {
            List<Tarefa> resultado = new List<Tarefa>();

            foreach (Tarefa tarefa in this.tarefas)
            {
                if (tarefa.Prioridade == p)
                {
                    resultado.Add(tarefa);
                }
            }

            return resultado;
        }

        public int totalAbertas()
        {
            return this.tarefasPorStatus("Aberta").Count;
        }

        public int totalFechadas()
        {
            return this.tarefasPorStatus("Fechada").Count;
        }
    }
}