﻿using System;
using System.Collections.Generic;

namespace Trabalho_Gerenciador_Projetos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Projetos projetos = new Projetos();
            int opcao;

            do
            {
                Console.Clear();

                Console.WriteLine("===== GERENCIADOR DE PROJETOS =====");
                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Adicionar projeto");
                Console.WriteLine("2. Pesquisar projeto");
                Console.WriteLine("3. Remover projeto");
                Console.WriteLine("4. Adicionar tarefa em projeto");
                Console.WriteLine("5. Concluir tarefa");
                Console.WriteLine("6. Cancelar tarefa");
                Console.WriteLine("7. Reabrir tarefa");
                Console.WriteLine("8. Listar tarefas de um projeto");
                Console.WriteLine("9. Filtrar tarefas de um projeto");
                Console.WriteLine("10. Filtrar tarefas de todos os projetos");
                Console.WriteLine("11. Resumo geral");
                Console.WriteLine();

                Console.Write("Opção: ");
                opcao = int.Parse(Console.ReadLine());

                Console.WriteLine();

                switch (opcao)
                {
                    case 0:
                        Console.WriteLine("Programa encerrado.");
                        break;

                    case 1:
                        adicionarProjeto(projetos);
                        break;

                    case 2:
                        pesquisarProjeto(projetos);
                        break;

                    case 3:
                        removerProjeto(projetos);
                        break;

                    case 4:
                        adicionarTarefa(projetos);
                        break;

                    case 5:
                        concluirTarefa(projetos);
                        break;

                    case 6:
                        cancelarTarefa(projetos);
                        break;

                    case 7:
                        reabrirTarefa(projetos);
                        break;

                    case 8:
                        listarTarefasProjeto(projetos);
                        break;

                    case 9:
                        filtrarProjeto(projetos);
                        break;

                    case 10:
                        filtrarTodos(projetos);
                        break;

                    case 11:
                        resumoGeral(projetos);
                        break;

                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }

                if (opcao != 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("Pressione ENTER para continuar...");
                    Console.ReadLine();
                }

            } while (opcao != 0);
        }

        static void adicionarProjeto(Projetos projetos)
        {
            Console.Write("ID do projeto: ");
            int id = int.Parse(Console.ReadLine());

            if (projetos.buscar(new Projeto(id, "")) != null)
            {
                Console.WriteLine("Já existe um projeto com esse ID.");
                return;
            }

            Console.Write("Nome do projeto: ");
            string nome = Console.ReadLine();

            Projeto projeto = new Projeto(id, nome);

            if (projetos.adicionar(projeto))
            {
                Console.WriteLine("Projeto adicionado com sucesso.");
            }
            else
            {
                Console.WriteLine("Não foi possível adicionar o projeto.");
            }
        }

        static Projeto procurarProjeto(Projetos projetos)
        {
            Console.Write("Informe o ID do projeto: ");
            int id = int.Parse(Console.ReadLine());

            return projetos.buscar(new Projeto(id, ""));
        }

        static Tarefa procurarTarefa(Projeto projeto)
        {
            Console.Write("Informe o ID da tarefa: ");
            int id = int.Parse(Console.ReadLine());

            return projeto.buscarTarefa(
                new Tarefa(id, "", "", 3)
            );
        }

        static void pesquisarProjeto(Projetos projetos)
        {
            Projeto projeto = procurarProjeto(projetos);

            if (projeto == null)
            {
                Console.WriteLine("Projeto não encontrado.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("===== PROJETO =====");
            Console.WriteLine("ID: " + projeto.Id);
            Console.WriteLine("Nome: " + projeto.Nome);
            Console.WriteLine("Total de tarefas: " + projeto.Tarefas.Count);
            Console.WriteLine("Abertas: " + projeto.totalAbertas());
            Console.WriteLine("Fechadas: " + projeto.totalFechadas());
            Console.WriteLine("Canceladas: " +
                projeto.tarefasPorStatus("Cancelada").Count);

            Console.WriteLine();
            Console.WriteLine("===== TAREFAS ABERTAS =====");
            mostrarTarefas(projeto.tarefasPorStatus("Aberta"));

            Console.WriteLine();
            Console.WriteLine("===== TAREFAS FECHADAS =====");
            mostrarTarefas(projeto.tarefasPorStatus("Fechada"));

            Console.WriteLine();
            Console.WriteLine("===== TAREFAS CANCELADAS =====");
            mostrarTarefas(projeto.tarefasPorStatus("Cancelada"));
        }

        static void removerProjeto(Projetos projetos)
        {
            Projeto projeto = procurarProjeto(projetos);

            if (projeto == null)
            {
                Console.WriteLine("Projeto não encontrado.");
                return;
            }

            if (projeto.Tarefas.Count > 0)
            {
                Console.WriteLine(
                    "O projeto não pode ser removido porque possui tarefas."
                );
                return;
            }

            if (projetos.remover(projeto))
            {
                Console.WriteLine("Projeto removido com sucesso.");
            }
            else
            {
                Console.WriteLine("Não foi possível remover o projeto.");
            }
        }

        static void adicionarTarefa(Projetos projetos)
        {
            Projeto projeto = procurarProjeto(projetos);

            if (projeto == null)
            {
                Console.WriteLine("Projeto não encontrado.");
                return;
            }

            Console.Write("ID da tarefa: ");
            int id = int.Parse(Console.ReadLine());

            if (projeto.buscarTarefa(new Tarefa(id, "", "", 3)) != null)
            {
                Console.WriteLine("Já existe uma tarefa com esse ID nesse projeto.");
                return;
            }

            Console.Write("Título: ");
            string titulo = Console.ReadLine();

            Console.Write("Descrição: ");
            string descricao = Console.ReadLine();

            Console.Write("Prioridade (1=Alta, 2=Média, 3=Baixa): ");
            int prioridade = int.Parse(Console.ReadLine());

            if (prioridade < 1 || prioridade > 3)
            {
                Console.WriteLine("Prioridade inválida.");
                return;
            }

            Tarefa tarefa =
                new Tarefa(id, titulo, descricao, prioridade);

            projeto.adicionarTarefa(tarefa);

            Console.WriteLine("Tarefa adicionada com sucesso.");
        }

        static void concluirTarefa(Projetos projetos)
        {
            Projeto projeto = procurarProjeto(projetos);

            if (projeto == null)
            {
                Console.WriteLine("Projeto não encontrado.");
                return;
            }

            Tarefa tarefa = procurarTarefa(projeto);

            if (tarefa == null)
            {
                Console.WriteLine("Tarefa não encontrada.");
                return;
            }

            tarefa.concluir();

            Console.WriteLine("Tarefa concluída com sucesso.");
        }

        static void cancelarTarefa(Projetos projetos)
        {
            Projeto projeto = procurarProjeto(projetos);

            if (projeto == null)
            {
                Console.WriteLine("Projeto não encontrado.");
                return;
            }

            Tarefa tarefa = procurarTarefa(projeto);

            if (tarefa == null)
            {
                Console.WriteLine("Tarefa não encontrada.");
                return;
            }

            tarefa.cancelar();

            Console.WriteLine("Tarefa cancelada com sucesso.");
        }

        static void reabrirTarefa(Projetos projetos)
        {
            Projeto projeto = procurarProjeto(projetos);

            if (projeto == null)
            {
                Console.WriteLine("Projeto não encontrado.");
                return;
            }

            Tarefa tarefa = procurarTarefa(projeto);

            if (tarefa == null)
            {
                Console.WriteLine("Tarefa não encontrada.");
                return;
            }

            tarefa.reabrir();

            Console.WriteLine("Tarefa reaberta com sucesso.");
        }

        static void listarTarefasProjeto(Projetos projetos)
        {
            Projeto projeto = procurarProjeto(projetos);

            if (projeto == null)
            {
                Console.WriteLine("Projeto não encontrado.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("Projeto: " + projeto.Nome);

            mostrarTarefas(projeto.Tarefas);
        }

        static void filtrarProjeto(Projetos projetos)
        {
            Projeto projeto = procurarProjeto(projetos);

            if (projeto == null)
            {
                Console.WriteLine("Projeto não encontrado.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("1. Filtrar por status");
            Console.WriteLine("2. Filtrar por prioridade");
            Console.Write("Opção: ");

            int opcao = int.Parse(Console.ReadLine());

            if (opcao == 1)
            {
                Console.WriteLine();
                Console.WriteLine("1. Aberta");
                Console.WriteLine("2. Fechada");
                Console.WriteLine("3. Cancelada");
                Console.Write("Status: ");

                int escolha = int.Parse(Console.ReadLine());

                string status = converterStatus(escolha);

                if (status == "")
                {
                    Console.WriteLine("Status inválido.");
                    return;
                }

                mostrarTarefas(
                    projeto.tarefasPorStatus(status)
                );
            }
            else if (opcao == 2)
            {
                Console.Write(
                    "Prioridade (1=Alta, 2=Média, 3=Baixa): "
                );

                int prioridade = int.Parse(Console.ReadLine());

                if (prioridade < 1 || prioridade > 3)
                {
                    Console.WriteLine("Prioridade inválida.");
                    return;
                }

                mostrarTarefas(
                    projeto.tarefasPorPrioridade(prioridade)
                );
            }
            else
            {
                Console.WriteLine("Opção inválida.");
            }
        }

        static void filtrarTodos(Projetos projetos)
        {
            Console.WriteLine("1. Filtrar por status");
            Console.WriteLine("2. Filtrar por prioridade");
            Console.Write("Opção: ");

            int opcao = int.Parse(Console.ReadLine());

            if (opcao == 1)
            {
                Console.WriteLine();
                Console.WriteLine("1. Aberta");
                Console.WriteLine("2. Fechada");
                Console.WriteLine("3. Cancelada");
                Console.Write("Status: ");

                int escolha = int.Parse(Console.ReadLine());

                string status = converterStatus(escolha);

                if (status == "")
                {
                    Console.WriteLine("Status inválido.");
                    return;
                }

                foreach (Projeto projeto in projetos.listar())
                {
                    List<Tarefa> tarefas =
                        projeto.tarefasPorStatus(status);

                    if (tarefas.Count > 0)
                    {
                        Console.WriteLine();
                        Console.WriteLine(
                            "Projeto: " + projeto.Id +
                            " - " + projeto.Nome
                        );

                        mostrarTarefas(tarefas);
                    }
                }
            }
            else if (opcao == 2)
            {
                Console.Write(
                    "Prioridade (1=Alta, 2=Média, 3=Baixa): "
                );

                int prioridade = int.Parse(Console.ReadLine());

                if (prioridade < 1 || prioridade > 3)
                {
                    Console.WriteLine("Prioridade inválida.");
                    return;
                }

                foreach (Projeto projeto in projetos.listar())
                {
                    List<Tarefa> tarefas =
                        projeto.tarefasPorPrioridade(prioridade);

                    if (tarefas.Count > 0)
                    {
                        Console.WriteLine();
                        Console.WriteLine(
                            "Projeto: " + projeto.Id +
                            " - " + projeto.Nome
                        );

                        mostrarTarefas(tarefas);
                    }
                }
            }
            else
            {
                Console.WriteLine("Opção inválida.");
            }
        }

        static void resumoGeral(Projetos projetos)
        {
            int abertas = 0;
            int fechadas = 0;
            int canceladas = 0;

            foreach (Projeto projeto in projetos.listar())
            {
                abertas += projeto.totalAbertas();
                fechadas += projeto.totalFechadas();

                canceladas +=
                    projeto.tarefasPorStatus("Cancelada").Count;
            }

            Console.WriteLine("===== RESUMO GERAL =====");
            Console.WriteLine(
                "Quantidade de projetos: " +
                projetos.listar().Count
            );

            Console.WriteLine(
                "Tarefas abertas: " + abertas
            );

            Console.WriteLine(
                "Tarefas fechadas: " + fechadas
            );

            Console.WriteLine(
                "Tarefas canceladas: " + canceladas
            );

            if (abertas > 0)
            {
                double percentual =
                    (double)fechadas / abertas * 100;

                Console.WriteLine(
                    "% concluídas em relação às abertas: " +
                    percentual.ToString("F2") + "%"
                );
            }
            else
            {
                Console.WriteLine(
                    "% concluídas em relação às abertas: 0,00%"
                );
            }
        }

        static void mostrarTarefas(List<Tarefa> tarefas)
        {
            if (tarefas.Count == 0)
            {
                Console.WriteLine("Nenhuma tarefa encontrada.");
                return;
            }

            foreach (Tarefa tarefa in tarefas)
            {
                Console.WriteLine();
                Console.WriteLine("ID: " + tarefa.Id);
                Console.WriteLine("Título: " + tarefa.Titulo);
                Console.WriteLine(
                    "Descrição: " + tarefa.Descricao
                );
                Console.WriteLine(
                    "Prioridade: " +
                    textoPrioridade(tarefa.Prioridade)
                );
                Console.WriteLine(
                    "Status: " + tarefa.Status
                );
                Console.WriteLine(
                    "Data de criação: " +
                    tarefa.DataCriacao.ToString(
                        "dd/MM/yyyy HH:mm"
                    )
                );

                if (tarefa.Status == "Fechada")
                {
                    Console.WriteLine(
                        "Data de conclusão: " +
                        tarefa.DataConclusao.ToString(
                            "dd/MM/yyyy HH:mm"
                        )
                    );
                }

                Console.WriteLine("-----------------------------");
            }
        }

        static string textoPrioridade(int prioridade)
        {
            if (prioridade == 1)
            {
                return "Alta";
            }

            if (prioridade == 2)
            {
                return "Média";
            }

            return "Baixa";
        }

        static string converterStatus(int opcao)
        {
            if (opcao == 1)
            {
                return "Aberta";
            }

            if (opcao == 2)
            {
                return "Fechada";
            }

            if (opcao == 3)
            {
                return "Cancelada";
            }

            return "";
        }
    }
}