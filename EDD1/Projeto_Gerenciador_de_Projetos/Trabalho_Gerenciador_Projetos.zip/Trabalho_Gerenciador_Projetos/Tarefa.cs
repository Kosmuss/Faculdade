﻿using System;

namespace Trabalho_Gerenciador_Projetos
{
    internal class Tarefa
    {
        private int id;
        private string titulo;
        private string descricao;
        private int prioridade;
        private string status;
        private DateTime dataCriacao;
        private DateTime dataConclusao;

        public int Id
        {
            get => id;
            set => id = value;
        }

        public string Titulo
        {
            get => titulo;
            set => titulo = value;
        }

        public string Descricao
        {
            get => descricao;
            set => descricao = value;
        }

        public int Prioridade
        {
            get => prioridade;
            set => prioridade = value;
        }

        public string Status
        {
            get => status;
            set => status = value;
        }

        public DateTime DataCriacao
        {
            get => dataCriacao;
            set => dataCriacao = value;
        }

        public DateTime DataConclusao
        {
            get => dataConclusao;
            set => dataConclusao = value;
        }

        public Tarefa(int id, string titulo, string descricao, int prioridade)
        {
            this.Id = id;
            this.Titulo = titulo;
            this.Descricao = descricao;
            this.Prioridade = prioridade;
            this.Status = "Aberta";
            this.DataCriacao = DateTime.Now;
            this.DataConclusao = DateTime.MinValue;
        }

        public Tarefa() : this(0, "", "", 3)
        {
        }

        public void concluir()
        {
            this.Status = "Fechada";
            this.DataConclusao = DateTime.Now;
        }

        public void cancelar()
        {
            this.Status = "Cancelada";
            this.DataConclusao = DateTime.MinValue;
        }

        public void reabrir()
        {
            this.Status = "Aberta";
            this.DataConclusao = DateTime.MinValue;
        }
    }
}