﻿using System;
using System.Collections.Generic;

namespace Trabalho_Biblioteca
{
    internal class Livros
    {
        private List<Livro> acervo;

        public List<Livro> Acervo
        {
            get => acervo;
        }

        public Livros()
        {
            this.acervo = new List<Livro>();
        }

        public void adicionar(Livro livro)
        {
            this.acervo.Add(livro);
        }

        public Livro pesquisar(Livro livro)
        {
            foreach (Livro livroAcervo in this.acervo)
            {
                if (livroAcervo.Isbn == livro.Isbn)
                {
                    return livroAcervo;
                }
            }

            return null;
        }
    }
}