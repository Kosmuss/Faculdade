﻿using System;

namespace Trabalho_Biblioteca
{
    internal class Emprestimo
    {
        private DateTime dtEmprestimo;
        private DateTime dtDevolucao;

        public DateTime DtEmprestimo
        {
            get => dtEmprestimo;
            set => dtEmprestimo = value;
        }

        public DateTime DtDevolucao
        {
            get => dtDevolucao;
            set => dtDevolucao = value;
        }

        public Emprestimo(DateTime dtEmprestimo, DateTime dtDevolucao)
        {
            this.DtEmprestimo = dtEmprestimo;
            this.DtDevolucao = dtDevolucao;
        }

        public Emprestimo() : this(DateTime.Now, DateTime.MinValue)
        {
        }
    }
}