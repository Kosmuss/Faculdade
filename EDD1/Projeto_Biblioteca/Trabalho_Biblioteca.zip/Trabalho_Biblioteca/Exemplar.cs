﻿using System;
using System.Collections.Generic;

namespace Trabalho_Biblioteca
{
    internal class Exemplar
    {
        private int tombo;
        private List<Emprestimo> emprestimos;

        public int Tombo
        {
            get => tombo;
            set => tombo = value;
        }

        public List<Emprestimo> Emprestimos
        {
            get => emprestimos;
        }

        public Exemplar(int tombo)
        {
            this.Tombo = tombo;
            this.emprestimos = new List<Emprestimo>();
        }

        public Exemplar() : this(0)
        {
        }

        public bool emprestar()
        {
            if (!this.disponivel())
            {
                return false;
            }

            Emprestimo emprestimo =
                new Emprestimo(DateTime.Now, DateTime.MinValue);

            this.emprestimos.Add(emprestimo);

            return true;
        }

        public bool devolver()
        {
            for (int i = this.emprestimos.Count - 1; i >= 0; i--)
            {
                if (this.emprestimos[i].DtDevolucao == DateTime.MinValue)
                {
                    this.emprestimos[i].DtDevolucao = DateTime.Now;
                    return true;
                }
            }

            return false;
        }

        public bool disponivel()
        {
            foreach (Emprestimo emprestimo in this.emprestimos)
            {
                if (emprestimo.DtDevolucao == DateTime.MinValue)
                {
                    return false;
                }
            }

            return true;
        }

        public int qtdeEmprestimos()
        {
            return this.emprestimos.Count;
        }
    }
}