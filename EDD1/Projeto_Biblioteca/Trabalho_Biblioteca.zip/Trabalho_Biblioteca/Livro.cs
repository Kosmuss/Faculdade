﻿using System;
using System.Collections.Generic;

namespace Trabalho_Biblioteca
{
    internal class Livro
    {
        private int isbn;
        private string titulo;
        private string autor;
        private string editora;
        private List<Exemplar> exemplares;

        public int Isbn
        {
            get => isbn;
            set => isbn = value;
        }

        public string Titulo
        {
            get => titulo;
            set => titulo = value;
        }

        public string Autor
        {
            get => autor;
            set => autor = value;
        }

        public string Editora
        {
            get => editora;
            set => editora = value;
        }

        public List<Exemplar> Exemplares
        {
            get => exemplares;
        }

        public Livro(int isbn, string titulo, string autor, string editora)
        {
            this.Isbn = isbn;
            this.Titulo = titulo;
            this.Autor = autor;
            this.Editora = editora;
            this.exemplares = new List<Exemplar>();
        }

        public Livro() : this(0, "", "", "")
        {
        }

        public void adicionarExemplar(Exemplar exemplar)
        {
            this.exemplares.Add(exemplar);
        }

        public int qtdeExemplares()
        {
            return this.exemplares.Count;
        }

        public int qtdeDisponiveis()
        {
            int quantidade = 0;

            foreach (Exemplar exemplar in this.exemplares)
            {
                if (exemplar.disponivel())
                {
                    quantidade++;
                }
            }

            return quantidade;
        }

        public int qtdeEmprestimos()
        {
            int quantidade = 0;

            foreach (Exemplar exemplar in this.exemplares)
            {
                quantidade += exemplar.qtdeEmprestimos();
            }

            return quantidade;
        }

        public double percDisponibilidade()
        {
            if (this.qtdeExemplares() == 0)
            {
                return 0;
            }

            return (double)this.qtdeDisponiveis()
                   / this.qtdeExemplares() * 100;
        }
    }
}