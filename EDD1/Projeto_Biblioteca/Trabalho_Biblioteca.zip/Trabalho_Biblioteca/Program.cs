﻿using System;

namespace Trabalho_Biblioteca
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Livros livros = new Livros();
            int opcao;

            do
            {
                Console.Clear();

                Console.WriteLine("===== BIBLIOTECA =====");
                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Adicionar livro");
                Console.WriteLine("2. Pesquisar livro (sintético)");
                Console.WriteLine("3. Pesquisar livro (analítico)");
                Console.WriteLine("4. Adicionar exemplar");
                Console.WriteLine("5. Registrar empréstimo");
                Console.WriteLine("6. Registrar devolução");
                Console.WriteLine();

                Console.Write("Opção: ");
                opcao = int.Parse(Console.ReadLine());

                Console.WriteLine();

                switch (opcao)
                {
                    case 0:
                        Console.WriteLine("Programa encerrado.");
                        break;

                    case 1:
                        adicionarLivro(livros);
                        break;

                    case 2:
                        pesquisarSintetico(livros);
                        break;

                    case 3:
                        pesquisarAnalitico(livros);
                        break;

                    case 4:
                        adicionarExemplar(livros);
                        break;

                    case 5:
                        registrarEmprestimo(livros);
                        break;

                    case 6:
                        registrarDevolucao(livros);
                        break;

                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }

                if (opcao != 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("Pressione ENTER para continuar...");
                    Console.ReadLine();
                }

            } while (opcao != 0);
        }

        static void adicionarLivro(Livros livros)
        {
            Console.Write("ISBN: ");
            int isbn = int.Parse(Console.ReadLine());

            Livro existente =
                livros.pesquisar(new Livro(isbn, "", "", ""));

            if (existente != null)
            {
                Console.WriteLine("Já existe um livro com esse ISBN.");
                return;
            }

            Console.Write("Título: ");
            string titulo = Console.ReadLine();

            Console.Write("Autor: ");
            string autor = Console.ReadLine();

            Console.Write("Editora: ");
            string editora = Console.ReadLine();

            Livro livro =
                new Livro(isbn, titulo, autor, editora);

            livros.adicionar(livro);

            Console.WriteLine("Livro adicionado com sucesso.");
        }

        static Livro procurarLivro(Livros livros)
        {
            Console.Write("Informe o ISBN: ");
            int isbn = int.Parse(Console.ReadLine());

            return livros.pesquisar(
                new Livro(isbn, "", "", "")
            );
        }

        static void mostrarDadosBasicos(Livro livro)
        {
            Console.WriteLine("ISBN: " + livro.Isbn);
            Console.WriteLine("Título: " + livro.Titulo);
            Console.WriteLine("Autor: " + livro.Autor);
            Console.WriteLine("Editora: " + livro.Editora);

            Console.WriteLine(
                "Total de exemplares: " +
                livro.qtdeExemplares()
            );

            Console.WriteLine(
                "Exemplares disponíveis: " +
                livro.qtdeDisponiveis()
            );

            Console.WriteLine(
                "Total de empréstimos: " +
                livro.qtdeEmprestimos()
            );

            Console.WriteLine(
                "Percentual de disponibilidade: " +
                livro.percDisponibilidade().ToString("F2") +
                "%"
            );
        }

        static void pesquisarSintetico(Livros livros)
        {
            Livro livro = procurarLivro(livros);

            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("===== LIVRO =====");

            mostrarDadosBasicos(livro);
        }

        static void pesquisarAnalitico(Livros livros)
        {
            Livro livro = procurarLivro(livros);

            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("===== LIVRO =====");

            mostrarDadosBasicos(livro);

            Console.WriteLine();
            Console.WriteLine("===== EXEMPLARES =====");

            if (livro.Exemplares.Count == 0)
            {
                Console.WriteLine("Nenhum exemplar cadastrado.");
                return;
            }

            foreach (Exemplar exemplar in livro.Exemplares)
            {
                Console.WriteLine();
                Console.WriteLine("Tombo: " + exemplar.Tombo);

                if (exemplar.disponivel())
                {
                    Console.WriteLine("Situação: Disponível");
                }
                else
                {
                    Console.WriteLine("Situação: Emprestado");
                }

                Console.WriteLine(
                    "Quantidade de empréstimos: " +
                    exemplar.qtdeEmprestimos()
                );

                Console.WriteLine("Empréstimos:");

                if (exemplar.Emprestimos.Count == 0)
                {
                    Console.WriteLine("Nenhum empréstimo registrado.");
                }
                else
                {
                    foreach (Emprestimo emprestimo
                             in exemplar.Emprestimos)
                    {
                        Console.WriteLine(
                            "Data do empréstimo: " +
                            emprestimo.DtEmprestimo.ToString(
                                "dd/MM/yyyy HH:mm"
                            )
                        );

                        if (emprestimo.DtDevolucao ==
                            DateTime.MinValue)
                        {
                            Console.WriteLine(
                                "Data da devolução: Não devolvido"
                            );
                        }
                        else
                        {
                            Console.WriteLine(
                                "Data da devolução: " +
                                emprestimo.DtDevolucao.ToString(
                                    "dd/MM/yyyy HH:mm"
                                )
                            );
                        }

                        Console.WriteLine();
                    }
                }

                Console.WriteLine("-----------------------------");
            }
        }

        static void adicionarExemplar(Livros livros)
        {
            Livro livro = procurarLivro(livros);

            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado.");
                return;
            }

            Console.Write("Informe o número do tombo: ");
            int tombo = int.Parse(Console.ReadLine());

            foreach (Exemplar exemplar in livro.Exemplares)
            {
                if (exemplar.Tombo == tombo)
                {
                    Console.WriteLine(
                        "Já existe um exemplar com esse tombo."
                    );

                    return;
                }
            }

            livro.adicionarExemplar(
                new Exemplar(tombo)
            );

            Console.WriteLine(
                "Exemplar adicionado com sucesso."
            );
        }

        static Exemplar procurarExemplar(Livro livro)
        {
            Console.Write("Informe o tombo do exemplar: ");
            int tombo = int.Parse(Console.ReadLine());

            foreach (Exemplar exemplar in livro.Exemplares)
            {
                if (exemplar.Tombo == tombo)
                {
                    return exemplar;
                }
            }

            return null;
        }

        static void registrarEmprestimo(Livros livros)
        {
            Livro livro = procurarLivro(livros);

            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado.");
                return;
            }

            Exemplar exemplar = procurarExemplar(livro);

            if (exemplar == null)
            {
                Console.WriteLine("Exemplar não encontrado.");
                return;
            }

            if (exemplar.emprestar())
            {
                Console.WriteLine(
                    "Empréstimo registrado com sucesso."
                );
            }
            else
            {
                Console.WriteLine(
                    "O exemplar já está emprestado."
                );
            }
        }

        static void registrarDevolucao(Livros livros)
        {
            Livro livro = procurarLivro(livros);

            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado.");
                return;
            }

            Exemplar exemplar = procurarExemplar(livro);

            if (exemplar == null)
            {
                Console.WriteLine("Exemplar não encontrado.");
                return;
            }

            if (exemplar.devolver())
            {
                Console.WriteLine(
                    "Devolução registrada com sucesso."
                );
            }
            else
            {
                Console.WriteLine(
                    "O exemplar não possui empréstimo em aberto."
                );
            }
        }
    }
}